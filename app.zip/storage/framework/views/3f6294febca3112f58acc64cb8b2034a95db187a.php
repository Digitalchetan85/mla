<div>
    <div id="section-header" class="py-3 py-md-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="border-start border-primary border-5">
                        <h2 class="fs-3 ms-3 text-primary">Good Morning Denduluru</h2>
                        <nav aria-label="breadcrumb" class="ms-3">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                <li class="breadcrumb-item"><a href="#">My Contituency</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Good Morning Denduluru</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="development" class="py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6 align-self-center">
                    <div class="text-center">
                        <img src="<?php echo e(asset('assets/images/test1.png')); ?>" alt="" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-6 align-self-center">
                    <div class="text-center">
                        <img src="<?php echo e(asset('assets/images/test2.png')); ?>" alt="" class="img-fluid">
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

    
</div><?php /**PATH C:\xampp\htdocs\mla\resources\views/livewire/events/good-morning-denduluru.blade.php ENDPATH**/ ?>