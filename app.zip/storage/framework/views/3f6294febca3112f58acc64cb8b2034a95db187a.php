<div id="bg-light">
    <div id="section-header" class="py-3">
        <div class="container">
            <div class="row">
                <div class="col-md-12 align-self-center">
                    <div class="border-start border-primary border-5 mb-0">
                        <h2 class="fs-3 ms-3 text-primary">GADAPA GADAPAKU MANA PRABHUTVAM </h2>
                        <nav aria-label="breadcrumb" class="ms-3">
                            <ol class="breadcrumb mb-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                <li class="breadcrumb-item"><a href="#">My Contituency</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Good Morning Denduluru</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="dev-1" class="py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p class="text-center">
                        The prime objective of the Gadapa Gadapaku Mana Prabhutvam, it said, is to create awareness
                        among the public about the schemes and programmes of the government; to ensure that the benefits
                        reach the last mile beneficiary covering all the eligible beneficiaries; and seek feedback
                        /suggestions from the public for process improvement and further improve the service delivery.”</p>

                        <p class="text-center">The MLAs would make visits to the households in their jurisdiction as per the schedule finalised
                        by the respective district collectors within the limits of Grama/Ward Sachivalayam. The MLAs
                        shall visit all the households in all Villages/Wards along with public representatives and
                        officers at Mandal/Municipality and Village/ Ward levels .
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div id="development" class="py-3 py-md-5">
        <div class="container">
            <div class="owl-carousel owl-theme" id="good">
                <div class="item">
                    <div class="text-center">
                        <img src="<?php echo e(asset('assets/images/ban-1.png')); ?>" alt="" class="img-fluid">
                    </div>
                </div>
                <div class="item">
                    <div class="text-center">
                        <img src="<?php echo e(asset('assets/images/ban-2.png')); ?>" alt="" class="img-fluid">
                    </div>
                </div>
                <div class="item">
                    <div class="text-center">
                        <img src="<?php echo e(asset('assets/images/ban-3.png')); ?>" alt="" class="img-fluid">
                    </div>
                </div>
                <div class="item">
                    <div class="text-center">
                        <img src="<?php echo e(asset('assets/images/ban-3.png')); ?>" alt="" class="img-fluid">
                    </div>
                </div>
            </div>
            
        </div>
    </div>

    
</div><?php /**PATH C:\xampp\htdocs\mla\resources\views/livewire/events/good-morning-denduluru.blade.php ENDPATH**/ ?>