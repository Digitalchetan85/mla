<div>
    <div id="banner" class="position-relative bg-light">
        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                    aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                    aria-current="true" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                    aria-current="true" aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <a href="<?php echo e(route('registration')); ?>" class="text-decoration-none"><img src="<?php echo e(asset('assets/images/ban-1.png')); ?>" class="img-fluid w-100" alt="..."></a>
                    <div class="custom ms-2 ms-md-5 position-absolute top-50 start-0 translate-middle-y text-center w-50">
                        
                        
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="<?php echo e(asset('assets/images/ban-2.png')); ?>" class="img-fluid w-100" alt="...">
                    <div class="custom position-absolute top-50 start-0 translate-middle-y text-center w-50 ms-auto">
                        
                        <div class="text-center">
                            <a href="<?php echo e(route('skill')); ?>" class="btn btn-primary rounded text-decoration-none">Register Now!!!</a>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <a href="<?php echo e(route('skill')); ?>" class="text-decoration-none"><img src="<?php echo e(asset('assets/images/ban-3.png')); ?>" class="img-fluid w-100" alt="..."></a>
                    <div class="custom ms-2 ms-md-5 position-absolute top-50 start-0 translate-middle-y text-center w-50">
                        
                        <div class="text-center">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="about" class="py-3 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="text-center">
                        <img src="<?php echo e(asset('assets/images/about.png')); ?>" alt="" class="img-fluid">
                    </div>
                </div>
                <div class="col-md-8 bg-white align-self-center shadow py-3 rounded">
                    <h2 class="text-primary">About ABBAYA CHOWDARY KOTARU</h2>
                    <p>Abbaya Chowdary is Member of legislative assembly (MLA) in Government of Andhra Pradesh. The
                        young MLA has taken the responsibility to develop constituency with his exceptional people,
                        project and program management skills and excellent relationship management skills.</p>

                    <p> The prime focus of Abbaya Chowdary is to mobilize investments, create IT ecosystem, and
                        encouraging innovation and start-up activities. Abbaya Chowdary technology team is looking to
                        partner with Innovative IT product and consulting companies to setup operations in the state of
                        Andhra Pradesh and create more opportunities to the youth of the State.</p>

                    <p> Abbaya Chowdary is a strategic thinker and served as Director of Pega Systems based in London
                        with over 15 years of IT experience in delivering large transformation projects for the world's
                        largest financial services companies like Deutsche Bank, ING, HSBC, Barclays, Rabo and Lloyds
                        Banking Group.</p>
                </div>
            </div>
        </div>
    </div>

    <div id="social" class="py-3 py-md-5 bg-light">
        <div class="container">
            <h2 class="py-2 text-center text-primary">Social Connect</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="text-center">
                        <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fkotaru9999&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="100%" height="500" style="border:none;overflow:hidden;margin-left:100px;" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
                    </div>
                </div>
                <div class="col-md-6">
                    <iframe style="border:none;" height="500" width="100%" data-tweet-url="https://twitter.com/AbbayaChowdary" src="data:text/html;charset=utf-8,%3Ca%20class%3D%22twitter-timeline%22%20href%3D%22https%3A//twitter.com/AbbayaChowdary%3Fref_src%3Dtwsrc%255Etfw%22%3ETweets%20by%20AbbayaChowdary%3C/a%3E%0A%3Cscript%20async%20src%3D%22https%3A//platform.twitter.com/widgets.js%22%20charset%3D%22utf-8%22%3E%3C/script%3E%0A"></iframe>
                    
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\mla\resources\views/livewire/home/home.blade.php ENDPATH**/ ?>