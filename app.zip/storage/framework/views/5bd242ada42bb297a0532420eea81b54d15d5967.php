<div>
    <div id="section-header" class="py-3 py-md-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="border-start border-primary border-5">
                        <h2 class="fs-3 ms-3 text-primary">Register</h2>
                        <nav aria-label="breadcrumb" class="ms-3">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Register</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    <div id="reg1" class="py-2 py-md-5 bg-light">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10 align-self-center">
                    <div class="row g-3 justify-content-center">
                        <div class="col-md-12">
                            <div class="">
                                <form class="px-3 py-3 bg-white rounded shadow">
                                    <h3 class="py-2 text-center fs-5 text-decoration-underline">Get in Touch</h3>
                                    <h2 class="text-center py-2 text-primary">A Man Who will Listen</h2>

                                    <div class="row mb-3 py-3 py-md-5">
                                        <div class="col-md-4">
                                            <div class="">
                                                <h2 class="py-2 text-primary text-center">Address</h2>
                                                <ul class="list-unstyled text-center">
                                                    <li>#483, 1st Floor,</li>
                                                    <li>8th Main, 10th Cross Road</li>
                                                    <li>Jeevan Bima Nagar - B'lore-75</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="">
                                                <h2 class="py-2 text-primary text-center">Email</h2>
                                                <div class="text-center">
                                                    <a href="#" class="text-decoration-none"><i
                                                            class="fa fa-envelope me-2"></i>dendulurumla64@gmail.com</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="">
                                                <h2 class="py-2 text-primary text-center">Social Connect</h2>
                                                <div class="text-center">
                                                    <i class="fa-brands fa-facebook-f ms-2 border rounded p-3"></i>
                                                    <i class="fa-brands fa-twitter ms-2 border rounded p-3"></i>
                                                    <i class="fa-brands fa-youtube ms-2 border rounded p-3"></i>
                                                    <i class="fa-brands fa-instagram ms-2 border rounded p-3"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row justify-content-center">
                                        <div class="col-md-8">
                                            <div class="input-group mb-3">
                                                <span class="input-group-text" id="basic-addon1"><i
                                                        class="fa fa-user text-primary"></i></span>
                                                <input type="text" class="form-control" placeholder="Name"
                                                    aria-label="Username" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row justify-content-center">
                                        <div class="col-md-8">
                                            <div class="input-group mb-3">
                                                <span class="input-group-text" id="basic-addon1"><i
                                                        class="fa fa-building text-primary"></i></span>
                                                <select class="form-select" aria-label="Default select example">
                                                    <option selected>--Mandalam--</option>
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row justify-content-center">
                                        <div class="col-md-8">
                                            <div class="input-group mb-3">
                                                <span class="input-group-text" id="basic-addon1"><i
                                                        class="fa fa-building text-primary"></i></span>
                                                <input type="text" class="form-control" placeholder="Village"
                                                    aria-label="Username" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row justify-content-center">
                                        <div class="col-md-8">
                                            <div class="input-group mb-3">
                                                <span class="input-group-text" id="basic-addon1"><i
                                                        class="fa fa-phone-volume text-primary"></i></span>
                                                <input type="tel" class="form-control" placeholder="Contact No"
                                                    aria-label="Username" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row justify-content-center">
                                        <div class="col-md-8">
                                            <div class="input-group mb-3">
                                                <span class="input-group-text" id="basic-addon1"><i
                                                        class="fa fa-edit text-primary"></i></span>
                                                <textarea class="form-control" placeholder="Mention your concern!!!"
                                                    aria-label="Username" aria-describedby="basic-addon1"
                                                    rows="8"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-3 justify-content-center">
                                        <div class="col-md-8">
                                            <button type="button" class="btn btn-primary form-control">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\mla\resources\views/livewire/registration.blade.php ENDPATH**/ ?>