<?php

namespace App\Http\Livewire\Events;

use Livewire\Component;

class JaganMaata extends Component
{
    public function render()
    {
        return view('livewire.events.jagan-maata')->layout('layouts.page');
    }
}
