<?php

namespace App\Http\Livewire\Events;

use Livewire\Component;

class SkillUpDenduluru extends Component
{
    public function render()
    {
        return view('livewire.events.skill-up-denduluru')->layout('layouts.page');
    }
}
