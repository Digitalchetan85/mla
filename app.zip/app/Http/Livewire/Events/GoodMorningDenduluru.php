<?php

namespace App\Http\Livewire\Events;

use Livewire\Component;

class GoodMorningDenduluru extends Component
{
    public function render()
    {
        return view('livewire.events.good-morning-denduluru')->layout('layouts.page');
    }
}
