// $(document).ready(function() {
//     $('.dropdown-toggle').dropdownHover();
// })

// $('.navbar [data-toggle="dropdown"]').bootstrapDropdownHover({
//     // see next for specifications
//     setHideTimeout:200
// });
