<?php return array (
  'constituency.development-activities' => 'App\\Http\\Livewire\\Constituency\\DevelopmentActivities',
  'constituency.welfair-activities' => 'App\\Http\\Livewire\\Constituency\\WelfairActivities',
  'contact' => 'App\\Http\\Livewire\\Contact',
  'events.good-morning-denduluru' => 'App\\Http\\Livewire\\Events\\GoodMorningDenduluru',
  'events.jagan-maata' => 'App\\Http\\Livewire\\Events\\JaganMaata',
  'events.skill-up-denduluru' => 'App\\Http\\Livewire\\Events\\SkillUpDenduluru',
  'home.home' => 'App\\Http\\Livewire\\Home\\Home',
  'registration' => 'App\\Http\\Livewire\\Registration',
);